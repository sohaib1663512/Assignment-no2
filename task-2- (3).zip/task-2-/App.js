import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ActivityIndicator, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';

const ProfileScreen = () => {
  const [user, setUser] = useState({ name: '', email: '', phone: '' });
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);

  // Fetch user details from API
  const fetchUser = async () => {
    try {
      const storedUser = await AsyncStorage.getItem('userProfile');
      if (storedUser) {
        setUser(JSON.parse(storedUser));
      } else {
        const response = await axios.get('https://jsonplaceholder.typicode.com/users/1');
        setUser(response.data);
        await AsyncStorage.setItem('userProfile', JSON.stringify(response.data));
      }
    } catch (error) {
      console.error('Error fetching user:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUser();
  }, []);

  // Save updated profile
  const saveProfile = async () => {
    await AsyncStorage.setItem('userProfile', JSON.stringify(user));
    setEditing(false);
  };

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#007bff" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Profile</Text>
      
      <TextInput
        style={styles.input}
        value={user.name}
        onChangeText={(text) => setUser({ ...user, name: text })}
        editable={editing}
      />

      <TextInput
        style={styles.input}
        value={user.email}
        onChangeText={(text) => setUser({ ...user, email: text })}
        editable={editing}
        keyboardType="email-address"
      />

      <TextInput
        style={styles.input}
        value={user.phone}
        onChangeText={(text) => setUser({ ...user, phone: text })}
        editable={editing}
        keyboardType="phone-pad"
      />

      {editing ? (
        <TouchableOpacity style={styles.saveButton} onPress={saveProfile}>
          <Text style={styles.buttonText}>Save</Text>
        </TouchableOpacity>
      ) : (
        <TouchableOpacity style={styles.editButton} onPress={() => setEditing(true)}>
          <Text style={styles.buttonText}>Edit</Text>
        </TouchableOpacity>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#fff' },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20, textAlign: 'center' },
  input: {
    borderWidth: 1, borderColor: '#ccc', padding: 10, marginBottom: 10, borderRadius: 8,
    backgroundColor: '#f9f9f9', fontSize: 16
  },
  editButton: { backgroundColor: '#007bff', padding: 12, borderRadius: 8, alignItems: 'center' },
  saveButton: { backgroundColor: 'green', padding: 12, borderRadius: 8, alignItems: 'center' },
  buttonText: { color: 'white', fontWeight: 'bold', fontSize: 16 },
});

export default ProfileScreen;

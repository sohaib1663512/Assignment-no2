import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, StyleSheet } from 'react-native';
import axios from 'axios';

const API_URL = 'https://jsonplaceholder.typicode.com/posts'; // Replace with your mock API

const ExpenseTracker = () => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTransactions();
  }, []);

  const fetchTransactions = async () => {
    try {
      const response = await axios.get(API_URL);
      const mockTransactions = response.data.slice(0, 10).map((item, index) => ({
        id: item.id,
        amount: (Math.random() * 200 - 100).toFixed(2), // Random income/expense
        category: index % 2 === 0 ? 'Income' : 'Expense',
        date: new Date().toDateString(),
      }));
      setTransactions(mockTransactions);
    } catch (error) {
      console.error('Error fetching transactions:', error);
    } finally {
      setLoading(false);
    }
  };

  const totalIncome = transactions
    .filter((t) => t.amount > 0)
    .reduce((acc, t) => acc + parseFloat(t.amount), 0)
    .toFixed(2);

  const totalExpenses = transactions
    .filter((t) => t.amount < 0)
    .reduce((acc, t) => acc + parseFloat(t.amount), 0)
    .toFixed(2);

  const balance = (totalIncome - Math.abs(totalExpenses)).toFixed(2);

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#E50914" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* 🔥 Summary Section */}
      <View style={styles.summaryContainer}>
        <Text style={styles.balanceText}>💰 Balance: ₹{balance}</Text>
        <Text style={styles.incomeText}>📈 Income: ₹{totalIncome}</Text>
        <Text style={styles.expenseText}>📉 Expenses: ₹{totalExpenses}</Text>
      </View>

      {/* 📜 Transactions List */}
      <Text style={styles.sectionTitle}>📑 Recent Transactions</Text>
      <FlatList
        data={transactions}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={[styles.transactionItem, item.amount > 0 ? styles.income : styles.expense]}>
            <Text style={styles.transactionText}>{item.category}</Text>
            <Text style={styles.amountText}>₹{item.amount}</Text>
            <Text style={styles.dateText}>{item.date}</Text>
          </View>
        )}
      />
    </View>
  );
};

/* 🎨 Stylish & Attractive Design */
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
    padding: 20,
  },
  summaryContainer: {
    backgroundColor: '#1e1e1e',
    padding: 15,
    borderRadius: 12,
    marginBottom: 15,
    alignItems: 'center',
  },
  balanceText: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#E50914',
    marginBottom: 5,
  },
  incomeText: {
    fontSize: 16,
    color: '#28a745',
    marginBottom: 5,
  },
  expenseText: {
    fontSize: 16,
    color: '#dc3545',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 10,
  },
  transactionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    backgroundColor: '#1e1e1e',
  },
  transactionText: {
    fontSize: 16,
    color: '#fff',
  },
  amountText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  dateText: {
    fontSize: 12,
    color: '#aaa',
  },
  income: {
    borderLeftWidth: 5,
    borderLeftColor: '#28a745',
  },
  expense: {
    borderLeftWidth: 5,
    borderLeftColor: '#dc3545',
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#121212',
  },
});

export default ExpenseTracker;

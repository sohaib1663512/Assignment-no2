import React, { useState, useEffect } from 'react';
import { 
  View, Text, TextInput, FlatList, Image, TouchableOpacity, 
  ActivityIndicator, StyleSheet, ScrollView 
} from 'react-native';
import axios from 'axios';
import { Ionicons } from '@expo/vector-icons'; 

const API_KEY = 'YOUR_API_KEY'; // Replace with your TMDB API Key
const MOVIE_CATEGORIES = {
  Bollywood: `https://api.themoviedb.org/3/discover/movie?api_key=${API_KEY}&with_original_language=hi`,
  Hollywood: `https://api.themoviedb.org/3/movie/popular?api_key=${API_KEY}&language=en-US`,
  Tollywood: `https://api.themoviedb.org/3/discover/movie?api_key=${API_KEY}&with_original_language=te`,
  SouthIndian: `https://api.themoviedb.org/3/discover/movie?api_key=${API_KEY}&with_original_language=ta`,
};
const EVENT_TYPES = [
  { type: 'Morning Event', image: 'https://via.placeholder.com/200' },
  { type: 'Evening Event', image: 'https://via.placeholder.com/200' },
  { type: 'Dance Event', image: 'https://via.placeholder.com/200' },
  { type: 'Party Event', image: 'https://via.placeholder.com/200' },
  { type: 'Birthday Event', image: 'https://via.placeholder.com/200' },
];

const HomeScreen = () => {
  const [movies, setMovies] = useState({});
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetchMovies();
  }, []);

  const fetchMovies = async () => {
    try {
      let movieData = {};
      for (let category in MOVIE_CATEGORIES) {
        const response = await axios.get(MOVIE_CATEGORIES[category]);
        movieData[category] = response.data.results;
      }
      setMovies(movieData);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching movies:', error);
      setLoading(false);
    }
  };

  const handleSearch = (text) => {
    setSearch(text);
  };

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#E50914" />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      {/* 🎭 Header */}
      <Text style={styles.header}>🎟️ Book Your Ticket</Text>

      {/* 🔍 Search Bar */}
      <View style={styles.searchContainer}>
        <Ionicons name="search" size={20} color="#888" style={styles.searchIcon} />
        <TextInput
          style={styles.searchBar}
          placeholder="Search movies, events..."
          placeholderTextColor="#888"
          value={search}
          onChangeText={handleSearch}
        />
      </View>

      {/* 🎬 Movie Categories */}
      {Object.keys(movies).map((category) => (
        <View key={category}>
          <Text style={styles.sectionTitle}>🎥 {category} Movies</Text>
          <FlatList
            data={movies[category]}
            horizontal
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
              <TouchableOpacity style={styles.card}>
                <Image
                  source={{ uri: `https://image.tmdb.org/t/p/w500${item.poster_path}` }}
                  style={styles.cardImage}
                />
                <View style={styles.cardInfo}>
                  <Text style={styles.cardTitle} numberOfLines={1}>{item.title}</Text>
                  <Text style={styles.cardSubtitle}>📅 {item.release_date}</Text>
                  <Text style={styles.cardSubtitle}>📍 Mumbai, India</Text>
                </View>
              </TouchableOpacity>
            )}
          />
        </View>
      ))}

      {/* 🎤 Event Categories */}
      <Text style={styles.sectionTitle}>🎭 Events</Text>
      <FlatList
        data={EVENT_TYPES}
        horizontal
        keyExtractor={(item) => item.type}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.card}>
            <Image
              source={{ uri: item.image }}
              style={styles.cardImage}
            />
            <View style={styles.cardInfo}>
              <Text style={styles.cardTitle}>{item.type}</Text>
              <Text style={styles.cardSubtitle}>📍 Multiple Locations</Text>
            </View>
          </TouchableOpacity>
        )}
      />

      {/* ✈️ Travel Options */}
      <Text style={styles.sectionTitle}>✈️ Travel Options</Text>
      <View style={styles.travelContainer}>
        <TouchableOpacity style={[styles.travelOption, { backgroundColor: '#E50914' }]}>
          <Text style={styles.travelText}>🔥 First Class</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.travelOption, { backgroundColor: '#007bff' }]}>
          <Text style={styles.travelText}>💼 Business Class</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.travelOption, { backgroundColor: '#1e1e1e' }]}>
          <Text style={styles.travelText}>💺 Economy Class</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

/* 🎨 Stylish & Attractive Design */
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
    padding: 15,
  },
  header: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#E50914',
    marginBottom: 15,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1e1e1e',
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 8,
    marginBottom: 15,
  },
  searchIcon: {
    marginRight: 10,
  },
  searchBar: {
    flex: 1,
    fontSize: 16,
    color: '#fff',
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#fff',
    marginTop: 10,
    marginBottom: 10,
  },
  card: {
    backgroundColor: '#1e1e1e',
    borderRadius: 12,
    marginRight: 10,
    width: 150,
    overflow: 'hidden',
  },
  cardImage: {
    width: '100%',
    height: 180,
  },
  cardInfo: {
    padding: 10,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
  cardSubtitle: {
    fontSize: 12,
    color: '#aaa',
    marginTop: 3,
  },
  travelContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  travelOption: {
    flex: 1,
    padding: 15,
    marginHorizontal: 5,
    borderRadius: 10,
    alignItems: 'center',
  },
  travelText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#121212',
  },
});

export default HomeScreen;

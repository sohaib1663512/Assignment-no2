import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  StyleSheet,
  TextInput,
  Image,
  Animated,
} from 'react-native';
import axios from 'axios';

const API_URL = 'https://run.mocky.io/v3/2f06399e-d4b4-49b5-91a0-d5caa149a232'; // Mock API

const FoodDelivery = () => {
  const [restaurants, setRestaurants] = useState([]);
  const [filteredRestaurants, setFilteredRestaurants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const searchBarAnim = new Animated.Value(0);

  useEffect(() => {
    fetchRestaurants();
    Animated.timing(searchBarAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
  }, []);

  const fetchRestaurants = async () => {
    try {
      const response = await axios.get(API_URL);
      setRestaurants(response.data);
      setFilteredRestaurants(response.data);
    } catch (error) {
      console.error('Error fetching restaurants:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterByCuisine = (cuisine) => {
    if (cuisine === 'All') {
      setFilteredRestaurants(restaurants);
    } else {
      setFilteredRestaurants(restaurants.filter((r) => r.cuisine.toLowerCase().includes(cuisine.toLowerCase())));
    }
  };

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#E50914" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* 🔍 Animated Search Bar */}
      <Animated.View style={[styles.searchBarContainer, { opacity: searchBarAnim }]}>
        <TextInput
          style={styles.searchBar}
          placeholder="Search restaurants..."
          placeholderTextColor="#aaa"
          onChangeText={(text) => {
            setSearch(text);
            filterByCuisine(text);
          }}
          value={search}
        />
      </Animated.View>

      {/* 🍽️ Cuisine Filters */}
      <View style={styles.filterContainer}>
        {['All', 'Italian', 'Indian', 'Chinese', 'Mexican'].map((cuisine) => (
          <TouchableOpacity key={cuisine} style={styles.filterButton} onPress={() => filterByCuisine(cuisine)}>
            <Text style={styles.filterText}>{cuisine}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* 🍔 Restaurant List */}
      <FlatList
        data={filteredRestaurants}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Image source={{ uri: item.image }} style={styles.image} />
            <View style={styles.cardDetails}>
              <Text style={styles.restaurantName}>{item.name}</Text>
              <Text style={styles.cuisineText}>🍽️ {item.cuisine}</Text>
              <Text style={styles.ratingText}>⭐ {item.rating} / 5</Text>
            </View>
          </View>
        )}
      />
    </View>
  );
};

/* 🎨 Modern & Attractive UI */
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
    padding: 20,
  },
  searchBarContainer: {
    marginBottom: 10,
  },
  searchBar: {
    backgroundColor: '#1e1e1e',
    padding: 12,
    borderRadius: 15,
    color: 'white',
    fontSize: 16,
    paddingLeft: 15,
    elevation: 5,
  },
  filterContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  filterButton: {
    backgroundColor: '#E50914',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 15,
    shadowColor: '#E50914',
    shadowOpacity: 0.5,
    elevation: 5,
  },
  filterText: {
    color: 'white',
    fontWeight: 'bold',
  },
  card: {
    backgroundColor: '#1e1e1e',
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 15,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 5,
    flexDirection: 'row',
  },
  image: {
    width: 100,
    height: 100,
    borderTopLeftRadius: 20,
    borderBottomLeftRadius: 20,
  },
  cardDetails: {
    padding: 15,
    flex: 1,
  },
  restaurantName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
  },
  cuisineText: {
    fontSize: 14,
    color: '#bbb',
  },
  ratingText: {
    fontSize: 16,
    color: '#f4c430',
    marginTop: 5,
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#121212',
  },
});

export default FoodDelivery;

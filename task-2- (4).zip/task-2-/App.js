import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, FlatList, Alert, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';

const SeatSelectionScreen = () => {
  const [seats, setSeats] = useState([]);
  const [selectedSeats, setSelectedSeats] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSeats();
  }, []);

  const fetchSeats = async () => {
    try {
      const response = await axios.get('https://mockapi.com/seats'); // Replace with actual API
      setSeats(response.data);
    } catch (error) {
      Alert.alert('Error', 'Failed to fetch seat data');
    } finally {
      setLoading(false);
    }
  };

  const toggleSeatSelection = (seatId) => {
    setSelectedSeats((prev) =>
      prev.includes(seatId) ? prev.filter((id) => id !== seatId) : [...prev, seatId]
    );
  };

  const confirmSelection = async () => {
    try {
      await AsyncStorage.setItem('selectedSeats', JSON.stringify(selectedSeats));
      Alert.alert('Success', 'Your seats have been booked!');
    } catch (error) {
      Alert.alert('Error', 'Failed to save selection');
    }
  };

  if (loading) {
    return <Text style={styles.loadingText}>Loading seats...</Text>;
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Select Your Seats</Text>
      <FlatList
        data={seats}
        numColumns={4}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.seat, 
              item.booked ? styles.bookedSeat : 
              selectedSeats.includes(item.id) ? styles.selectedSeat : styles.availableSeat
            ]}
            disabled={item.booked}
            onPress={() => toggleSeatSelection(item.id)}
          >
            <Text style={styles.seatText}>{item.number}</Text>
          </TouchableOpacity>
        )}
      />
      <TouchableOpacity style={styles.confirmButton} onPress={confirmSelection}>
        <Text style={styles.confirmText}>Confirm Selection</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#fff' },
  title: { fontSize: 20, fontWeight: 'bold', textAlign: 'center', marginBottom: 20 },
  loadingText: { textAlign: 'center', fontSize: 16, marginTop: 20 },
  seat: { width: 50, height: 50, margin: 8, borderRadius: 8, justifyContent: 'center', alignItems: 'center' },
  availableSeat: { backgroundColor: '#28a745' },
  bookedSeat: { backgroundColor: '#dc3545' },
  selectedSeat: { backgroundColor: '#007bff' },
  seatText: { color: 'white', fontWeight: 'bold' },
  confirmButton: { marginTop: 20, padding: 15, backgroundColor: '#007bff', borderRadius: 10, alignItems: 'center' },
  confirmText: { color: 'white', fontSize: 16, fontWeight: 'bold' },
});

export default SeatSelectionScreen;
